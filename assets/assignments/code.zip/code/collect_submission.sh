rm -f assignment1.zip
python -m zipfile -c assignment1.zip vi_and_pi.py
